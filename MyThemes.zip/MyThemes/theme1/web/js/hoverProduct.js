require([

    'jquery'

], function ($) {
    $(window).ready(function(){
        console.log("hi");
        /*$("span.product-image-container").mouseover(function(){
           console.log("hello");*/
            // $("span.product-image-wrapper").append("<div style='background-color:rgba(0,0,0,0.7); height:100%;width:100%;z-index:20;position:absolute;'></div>");
       // });
    });
    
});