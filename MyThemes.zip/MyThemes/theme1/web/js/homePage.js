require([

    'jquery'

],function($){
    $(document).ready(function(){
        $('.wr-slider ul').bxSlider({
            pager: false,
            speed: 1000,
        });
        
        $('.wr-bestseller .products').bxSlider({
            pager: false,
            speed: 1000,
            minSlides: 1,
            maxSlides: 4,
            slideWidth: 270,
            slideMargin: 30,
            moveSlides: 1
        });
        
        
        
        $('.single-feature-product .products').bxSlider({
            pager: false,
            speed: 1000,
            minSlides: 1,
            maxSlides: 3,
            slideWidth: 270,
            slideMargin: 30,
            moveSlides: 1
        });
        
        $('.wr-wrapper-v2 .blog-slider').bxSlider({
            pager: false,
            speed: 1000,
            minSlides: 5,
            maxSlides: 5,
            moveSlides: 1,
            mode: 'vertical'
        });
        
        $('.wr-wrapper-v4 .blog-slider').bxSlider({
            pager: false,
            speed: 1000,
            minSlides: 4,
            maxSlides: 4,
            moveSlides: 1,
            mode: 'vertical'
        });
        
        $('.images-product .lager-slider').bxSlider({
          pagerCustom: '#thumb-slider',
          speed: 1000,
        });
        
        $('.thumb-slider li a').click(function(){
            var url_img = $(this).attr('href');
            $(this).parents('.images-product').find('#large-img').attr('href',url_img);
            $(this).parents('.images-product').find('#large-img img').fadeOut(300).attr('src', url_img).fadeIn(300);
            return false;
        });
    });
    
});