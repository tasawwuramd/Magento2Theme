require([

    'jquery'

], function ($) {
    $(window).ready(function(){
        $('.sidebar-menu > ul > li').click(function(){
            $(this).parent().find('.sub-menu').not($(this).find('.sub-menu')).slideUp(300);
            $(this).find('.sub-menu').toggle(300);
            $(this).toggleClass("opend");
            $(this).parent().find('li').not($(this)).removeClass('opend');
        });
        
        $('.navigation li .submenu').addClass("navigation-submenu");
        

        /*$(".products-grid span.product-image-container").on("mouseenter",function(){
            $(this).append("<div class='hoverCover' style='background-color:rgba(0,0,0,0.7); height:100%;width:100%;z-index:20;position:absolute;top:0;display:block;'></div>");
       });
       $("div.product-item-info").mouseleave(function(){
        $(".hoverCover").remove();     
        });*/

        $('field.limiter').click(function(){
            $('#limiter').click();
        });
        parallax_element();

        
});
/*$(document).ready(function () {
    $.stellar({
        horizontalScrolling: false,
        verticalOffset: 40
    });
});*/


/* ------ parallax icons ----*/

function parallax_element(){
	if($('.parallax-element').length){
		$('.parallax-element').each(function() {
            var pos = $(this).position().top - $( window ).height();
			var delay = 0;
			delay = $(this).attr('data-delay');
			if($(window).scrollTop()>=pos){
				if($(this).hasClass('intop')){
					$(this).addClass("outtop").delay(delay).queue(function(){
						$(this).removeClass("intop").stop().dequeue();
					});	
				}
				else if($(this).hasClass('inleft')){
					$(this).addClass("outleft").delay(delay).queue(function(){
						$(this).removeClass("inleft").stop().dequeue();
					});	
				}
				else if($(this).hasClass('inright')){
					$(this).addClass("outright").delay(delay).queue(function(){
						$(this).removeClass("inright").stop().dequeue();
					});	
				}
				else if($(this).hasClass('inbottom')){
					$(this).addClass("outbottom").delay(delay).queue(function(){
						$(this).removeClass("inbottom").stop().dequeue();
					});
				}
			}else{
				if($(this).hasClass('outtop')){
					$(this).removeClass('outtop').addClass('intop');
				}
				else if($(this).hasClass('outleft')){
					$(this).removeClass('outleft').addClass('inleft');
				}
				else if($(this).hasClass('outright')){
					$(this).removeClass('outright').addClass('inright');
				}
				else if($(this).hasClass('outbottom')){
					$(this).removeClass('outbottom').addClass('inbottom');
				}
			}
        });
	}	
}

/* ------- end parallax icons ------ */ 

    $(window).scroll(function(){
        parallax_element();
        var scrollTop = $(window).scrollTop();
        if($(window).scrollTop() > 300)
        {
            $('.header.content').css({position: "fixed", top:0}); 
            $('.header.content').css({height: "16%"});
            $('.header.content').css({"z-index": "16"});
            $('.logo img').height("50");
            $('.logo img').css({width:"70%"});
            $('.navigation li .submenu').removeClass("navigation-submenu");
            $('.navigation li .submenu').addClass("navigation-submenu-scroll");
            $('.navigation li .submenu').css({"box-shadow": "1px 1px 5px #CCC"});
        }
        else if($(window).scrollTop() < 200){
            $('.header.content').css({position: "static", top:0});
            $('.header.content').css({height: "20%"});
            $('.header.content').css({"z-index": "-1"});
            $('.logo img').height("60");
            $('.logo img').css({width:"90%"});
            $('.navigation li .submenu').removeClass("navigation-submenu-scroll");
            $('.navigation li .submenu').addClass("navigation-submenu");
            $('.navigation li .submenu').css({"box-shadow": "none"});
            
        }
    });
});